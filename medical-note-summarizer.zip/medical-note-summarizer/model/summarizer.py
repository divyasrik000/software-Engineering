from transformers import pipeline

summarizer = pipeline("summarization")

def summarize_note(note):
    result = summarizer(note, max_length=150, min_length=30, do_sample=False)
    return result[0]['summary_text']