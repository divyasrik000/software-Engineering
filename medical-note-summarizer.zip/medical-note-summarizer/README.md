# Medical Note Summarizer

A simple Streamlit app that uses Transformer-based NLP models to summarize lengthy medical notes.

## Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```