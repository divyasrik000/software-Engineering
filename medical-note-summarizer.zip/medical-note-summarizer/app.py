import streamlit as st
from model.summarizer import summarize_note

st.title("Medical Note Summarizer")

note = st.text_area("Paste a medical note:")
if st.button("Summarize"):
    summary = summarize_note(note)
    st.subheader("Summary")
    st.write(summary)