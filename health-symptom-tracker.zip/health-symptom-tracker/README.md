# Health Symptom Tracker

A simple personal project that logs daily health symptoms using a local frontend (React) and backend logic in Python for basic pattern analysis.

## Usage

1. Open `frontend/index.html` in browser
2. Log symptoms daily
3. Analyze `localStorage` data with `backend/analyze.py`