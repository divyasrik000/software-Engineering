const symptoms = JSON.parse(localStorage.getItem("symptoms") || "[]");

function logSymptom() {
  const input = document.getElementById("symptom").value;
  symptoms.push({ date: new Date().toISOString(), entry: input });
  localStorage.setItem("symptoms", JSON.stringify(symptoms));
  alert("Symptom logged!");
}