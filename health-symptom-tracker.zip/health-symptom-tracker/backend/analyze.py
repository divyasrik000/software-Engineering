import json

def analyze(filepath):
    with open(filepath) as f:
        data = json.load(f)
    freq = {}
    for entry in data:
        symptom = entry['entry'].lower()
        freq[symptom] = freq.get(symptom, 0) + 1
    return freq